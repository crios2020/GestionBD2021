show databases;
use negocioWeb;
show tables;

SELECT * from information_schema.VIEWS;

create view V_clientes_direcciones as
	select `c`.`id` AS `id`,`c`.`nombre` AS `nombre`,`c`.`apellido` AS `apellido`,`c`.`fenaci` AS `fenaci`,`c`.`tipoDocumento` AS `tipoDocumento`,`c`.`numeroDocumento` AS `numeroDocumento`,`c`.`telefono` AS `telefono`,`c`.`email` AS `email`,concat(`d`.`calle`,' ',`d`.`numero`,' ',`d`.`ciudad`) AS `direccion`,`c`.`comentarios` AS `comentarios` from (`negocioWeb`.`clientes` `c` join `negocioWeb`.`direcciones` `d` on(`c`.`idDireccion` = `d`.`id`));

CREATE view V_clientes_minima as
select concat(`negocioWeb`.`clientes`.`nombre`,' ',`negocioWeb`.`clientes`.`apellido`) AS `nombre_cliente`,`negocioWeb`.`clientes`.`telefono` AS `telefono` from `negocioWeb`.`clientes`;
CREATE view V_Indices as
select `i`.`INDEX_ID` AS `INDEX_ID`,`i`.`NAME` AS `Nombre Indice`,`t`.`NAME` AS `Nombre Tabla` from (`information_schema`.`INNODB_SYS_INDEXES` `i` join `information_schema`.`INNODB_SYS_TABLES` `t` on(`i`.`TABLE_ID` = `t`.`TABLE_ID`)) where `t`.`NAME` like 'negocioWeb%';

select * from V_Indices;
select * from V_clientes_direcciones;

select * from detalles d ;
describe articulos;
create view V_facturas as
	select
		f.id, f.letra, f.numero, f.fecha, f.hora, f.medioPago, f.comentarios, 
		c.id idCliente, c.nombre, c.apellido, c.fenaci fecha_nacimiento, c.tipoDocumento, c.numeroDocumento, c.telefono, c.email, c.direccion, c.comentarios comentarios_de_cliente,
		a.id idArticulo, a.nombre nombre_articulo, a.descripcion, a.tipo, a.especieRecomendada, a.costo, a.precio, a.stock, a.stockMinimo, a.stockMaximo, a.comentarios comentarios_de_articulo,
		d.cantidad cantidad_vendida, d.precioVenta
	 	from facturas f 
		join V_clientes_direcciones c on f.idCliente = c.id
		join detalles d on d.idFactura = f.id 
		join articulos a on a.id = d.idArticulo;
		
select * from V_facturas;

delimiter //
create procedure SP_test()
	begin
		select pi();
	end;
// delimiter ;

delimiter //
create procedure SP_test2()
	begin
		select curdate();	
	end;
// delimiter ;

call SP_test;
call SP_test2; 

create view V_Procedures as
	SELECT * from information_schema.ROUTINES;


create view V_Constraints
	select * from information_schema.TABLE_CONSTRAINTS where CONSTRAINT_SCHEMA='negocioWeb';

create view V_Vistas as
	SELECT * from information_schema.VIEWS;

create view V_Triggers as
	select * from information_schema.TRIGGERS;

show tables;
select * from V_Procedures;
select * from V_Vistas;
select * from V_Indices;