show tables;
select * from V_Functions;
select current_date();
select current_time();

-- usamos la UDF edad()
select edad("1973/02/02") edad;

select * from clientes;
select id, nombre, apellido, fenaci fecha_nacimiento, edad(fenaci) edad, telefono from clientes;

-- Triggers
drop trigger if exists TR_test;

/*
CREATE TRIGGER trigger_name
{BEFORE | AFTER} {INSERT | UPDATE| DELETE }
ON table_name FOR EACH ROW
trigger_body;
*/

delimiter //
create trigger TR_test 
	before insert
	on clientes 
	for each row
    begin
		SELECT 'Se ejecuto un trigger' INTO OUTFILE '/home/carlos/Descargas/salida.txt';
    end;
// delimiter ;

SELECT 'Hola' INTO OUTFILE '/home/carlos/Descargas/salida.txt';
drop table if exists control_tablas;
create table control_tablas(
	id int auto_increment primary key,
    tabla varchar(30) not null,
    accion enum('insert','delete','update') not null,
    fecha date not null,
    hora time not null,
    usuario varchar(20),
    terminal varchar(100),
    idRegistro int not null
);

delimiter //
create trigger TR_Clientes_Insert
	after insert
    on clientes for each row
    begin
		insert into control_tablas (tabla,accion,fecha,hora,usuario,terminal,idRegistro) 
        values 
        ('clientes','insert',current_date(),current_time(),current_user(), 
			(select user()),new.id);
    end;
// delimiter ;
call SP_Clientes_Insert('Juanito','Vialo','1958/06/05','DNI','12345624','1111111','nada@nada.com','viel',2222,'1','a','1010','CABA','CABA','Argentina','Comentarios');
show global variables;

select hostname from global variables;

select user();
select session_user();
select system_user();

select * from control_tablas;
select * from clientes;
show tables;
select * from V_Triggers;

drop trigger if exists TR_Clientes_Delete;

delimiter //
create trigger TR_Clientes_Delete
	after delete
    on clientes for each row
    begin
		insert into control_tablas (tabla,accion,fecha,hora,usuario,terminal,idRegistro) 
        values 
        ('clientes','delete',current_date(),current_time(),current_user(), 
			(select user()),old.id);
    end;
// delimiter ;

select * from V_Triggers;
select * from clientes;
delete from clientes where id=8;
select * from control_tablas;

drop trigger if exists TR_CLientes_Update;

delimiter //
	create trigger TR_Clientes_Update
    after update on clientes for each row
    begin
		insert into control_tablas (tabla,accion,fecha,hora,usuario,terminal,idRegistro) 
        values 
        ('clientes','update',current_date(),current_time(),current_user(), 
			(select user()),old.id);
    end;
// delimiter ;

update clientes set nombre='Karina', apellido='Vargas' where id=6;



 
