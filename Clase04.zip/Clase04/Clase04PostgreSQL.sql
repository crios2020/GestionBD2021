-- PostgreSQL

-- Consulta de catalogo de tablas en Postgresql
SELECT tablename
FROM pg_catalog.pg_tables
WHERE schemaname = 'public';
