-- use negocioWeb;

drop view if exists V_Procedures;
create view V_Procedures as
	SELECT * from information_schema.ROUTINES where ROUTINE_SCHEMA='negociowebcfp8' and ROUTINE_TYPE='PROCEDURE';

drop view if exists V_Functions;
create view V_Functions as
	SELECT * from information_schema.ROUTINES where ROUTINE_SCHEMA='negociowebcfp8' and ROUTINE_TYPE='FUNCTION';

drop view if exists V_Constraints;
create view V_Constraints as
	select * from information_schema.TABLE_CONSTRAINTS where CONSTRAINT_SCHEMA='negociowebcfp8';

drop view if exists V_Vistas;
create view V_Vistas as
	SELECT * from information_schema.VIEWS;

drop view if exists V_Triggers;
create view V_Triggers as
	select * from information_schema.TRIGGERS;

drop view if exists V_Indices;
create view V_Indices as
	select i.INDEX_ID, i.NAME Nombre_Indice, t.NAME  Nombre_Tabla 
		from INFORMATION_SCHEMA.INNODB_SYS_INDEXES i join INFORMATION_SCHEMA.INNODB_SYS_TABLES t on i.TABLE_ID = t.TABLE_ID
		where t.NAME like 'negociowebcfp8%';

show tables;
select * from V_Procedures;
select * from V_Functions;
select * from V_Vistas;
select * from V_Triggers;
select * from V_Indices;
