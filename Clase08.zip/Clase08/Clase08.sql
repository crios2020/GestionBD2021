select * from V_Procedures;
select * from V_Vistas;
select * from V_Triggers;


drop procedure if exists SP_Clientes_Insert;

delimiter //
create procedure SP_Clientes_Insert(in 
		Pnombre varchar(20), 
        Papellido varchar(20),
		Pfenaci date,
		PtipoDocumento enum('DNI','LC','LE','CI','PASS'),
        PnumeroDocumento char(8),
        Ptelefono varchar(16),
        Pemail varchar(50),
        Pcalle varchar(120),
        Pnumero int,
        Ppiso varchar(12),
        Pdepto varchar(12),
        PcodigoPostal varchar(12),
        Pciudad varchar(50),
        Pprovincia varchar(50),
        Ppais varchar(50),
        Pcomentarios varchar(255)
)
	begin
		insert into direcciones (calle,numero,piso,depto,codigoPostal,ciudad,provincia,pais) 
		 	values 
            (Pcalle,Pnumero,Ppiso,Pdepto,PcodigoPostal,Pciudad,Pprovincia,Ppais);
		insert into clientes (nombre,apellido,fenaci,tipoDocumento,numeroDocumento,telefono,email,idDireccion,comentarios)
		 	values
            (Pnombre,Papellido,Pfenaci,PtipoDocumento,PnumeroDocumento,Ptelefono,Pemail,
			(select max(id) from direcciones),Pcomentarios);
    end;
// delimiter ;



/*
	nombre=Juan&apellido=Perez&fenaci=2005/05/05&tipoDocumento=DNI&numeroDocumento=1111915&telefono=222222&email=nada@nada&calle=Viel&numero=10&piso=x&depto=x&codigoPostal=1111&ciudad=CABA&provincia=CABA&pais=Argentina&comentarios=x";
       
*/

call SP_Clientes_Insert('Juanita','Viale','1990/05/05','DNI','12345678','1111111','nada@nada.com','viel',2222,'1','a','1010','CABA','CABA','Argentina','Comentarios');
select * from clientes;
select * from direcciones;

drop procedure if exists SP_Clientes_Delete;

delimiter //
create procedure SP_Clientes_Delete(in Pid int)
	begin
		delete from clientes where id=Pid;
    end;
// delimiter ;

call SP_Clientes_Delete(1);

drop procedure if exists SP_Clientes_Update;

delimiter //
create procedure SP_Clientes_Update(in 
		Pid int,
		Pnombre varchar(20), 
        Papellido varchar(20),
		Pfenaci date,
		PtipoDocumento enum('DNI','LC','LE','CI','PASS'),
        PnumeroDocumento char(8),
        Ptelefono varchar(16),
        Pemail varchar(50),
        Pcalle varchar(120),
        Pnumero int,
        Ppiso varchar(12),
        Pdepto varchar(12),
        PcodigoPostal varchar(12),
        Pciudad varchar(50),
        Pprovincia varchar(50),
        Ppais varchar(50),
        Pcomentarios varchar(255)
        )
	begin
		update direcciones set calle=Pcalle, numero=Pnumero, piso=Ppiso, depto=Pdepto, 
			codigoPostal=PcodigoPostal, ciudad=Pciudad, provincia=Provincia, pais=Ppais
            where id=(select idDireccion from clientes where id=Pid);
		update clientes set nombre=Pnombre, apellido=Papellido, fenaci=Pfenaci, tipoDocumento=PtipoDocumento,
			numeroDocumento=PnumeroDocumento, telefono=Ptelefono, email=Pemail, comentarios=Pcomentarios 
            where id=Pid;
    end;
// delimiter ;

select * from clientes;

call sp_Clientes_Update(
		2,
		'Marcos', 
        'Celeste',
		(select fenaci from clientes where id=2),
		(select tipoDocumento from clientes where id=2),
        (select numeroDocumento from clientes where id=2),
        (select telefono from clientes where id=2),
        (select email from clientes where id=2),
        (select calle from direcciones where id=(select idDireccion from clientes where id=2)),
        (select numero from direcciones where id=(select idDireccion from clientes where id=2)),
        (select piso from direcciones where id=(select idDireccion from clientes where id=2)),
        (select depto from direcciones where id=(select idDireccion from clientes where id=2)),
        (select codigoPostal from direcciones where id=(select idDireccion from clientes where id=2)),
        (select ciudad from direcciones where id=(select idDireccion from clientes where id=2)),
        (select provincia from direcciones where id=(select idDireccion from clientes where id=2)),
        (select pais from direcciones where id=(select idDireccion from clientes where id=2)),
        (select comentarios from clientes where id=2)
);

-- User Define Function (UDF)

drop function if exists sumar;
delimiter //
create function sumar(nro1 int, nro2 int)
returns int
begin
	return (nro1+nro2);
end;
// delimiter ;

select sumar(2,2) resultado;	
select pi() PI;

SELECT * from information_schema.ROUTINES where ROUTINE_SCHEMA='negociowebcfp8' and ROUTINE_TYPE='FUNCTION';
SELECT * from information_schema.ROUTINES where ROUTINE_SCHEMA='negociowebcfp8' and ROUTINE_TYPE='PROCEDURE';

-- Produce un archivo de texto a partir de una consulta
SELECT * from information_schema.ROUTINES where ROUTINE_SCHEMA='negociowebcfp8' and ROUTINE_TYPE='PROCEDURE'
	 INTO OUTFILE '/home/carlos/Descargas/texto.txt'
     FIELDS TERMINATED BY ','
	 ENCLOSED BY '"'
	 LINES TERMINATED BY '\n';
	
select * from clientes;
select current_date();
select fenaci from clientes where id=2;
select current_date()-(select fenaci from clientes where id=2);

SELECT DATEDIFF(current_date, (select fenaci from clientes where id=2));

SELECT DATEDIFF(current_date, (select fenaci from clientes where id=2))/365.25;

SELECT round(DATEDIFF(current_date, (select fenaci from clientes where id=2))/365.25);

SELECT DATEDIFF(current_date, '1973/02/02')/365.25;

select truncate(DATEDIFF(current_date, '1973/02/02')/365.25,0);

drop function if exists edad;
delimiter //
create function edad(fenaci date)
returns date
begin
	return select truncate(DATEDIFF(current_date, date)/365.25,0);
end;
// delimiter ;
     
     






