/*
SQLite es un gestor de bases de datos relacional pero este gestor de base de datos tiene por 
objetivo ser parte de la misma aplicación con la que colabora, es decir no cumple los conceptos de 
cliente y servidor.

SQLite es Open Source y su sitio oficial es: sqlite.org

SQLite Browser: nos permitirá aprender todos los comandos del gestor de base de datos que luego lo 
accederemos desde nuestras propias aplicaciones en PHP, C#, Python, Android, iOS etc.

SQLite no usa CREATE DATABASE o DROP DATABASE como otras bases de datos. El mismo archivo de trabajo
es la base de datos.
*/

/* Bloque de comentarios */
-- comentarios de una sola linea
-- revisar char y varchar

drop table if exists clientes;
create table clientes(
	id integer primary key,			-- probar int que funciona
	nombre TEXT CHECK( LENGTH(nombre) <= 100 ) not null,
	apellido text not null,
	cuit text,
	direccion text,
	comentarios text
);

/*
-- error no es case sensitive
create table Clientes(
	id integer primary key,
	nombre text,
	apellido text,
	cuit text,
	direccion text,
	comentarios text
);
*/

/*
drop table if exists clientes2;
create table clientes2(
	id int primary key,			
	nombre varchar(45) CHECK( LENGTH(nombre) <= 100 ) not null,
	apellido char(40) not null,
	cuit text,
	direccion text,
	comentarios text,
	peso float,
	fenaci date
);
pragma table_info('clientes2');
select * from clientes2;
*/

-- CTRL R atajo de teclado para ejecutar la sentencia señalada

-- Catalogo de tablas
select * from sqlite_master;
SELECT name FROM sqlite_master WHERE type = "table";

-- describe la tabla
pragma table_info('clientes');

-- inserción de registros
insert into clientes (nombre,apellido,direccion) values 
	('Juan','Perez','Lima 222'),
	('Maria','Sosa','Maipu 345'),
	('Jose','Mendez','Viel 153');

select * from clientes;

-- AUTOINCREMENT
-- No existe el auto_increment, los campos integer declarados PRIMARY KEY, si no se coloca valor en la
-- sentencia insert, asumen el rol de auto incrementables.
-- Lo importante de hacer notar que el gestor SQLite siempre que creamos una tabla genera un campo extra 
-- llamado 'rowid' con un valor integer autoincremental. Luego el campo codigo al ser primary key en 
-- realidad es un alias del campo 'rowid'.
select rowid,id,nombre,apellido,cuit,direccion,comentarios from clientes;

/*
Tipos de datos básicos para definir los campos de una tabla
Estos son algunos tipos de datos básicos de SQLite:

    text: se usa para almacenar cadenas de caracteres. Una cadena es una secuencia de caracteres. 
			Se coloca entre comillas (simples); ejemplo: 'Hola', 'Juan Perez'. El tipo "text" define una 
			cadena de longitud variable.

    integer: se usa para guardar valores numéricos enteros. Definimos campos de este tipo cuando 
			queremos representar, por ejemplo, cantidades.

    real: se usa para almacenar valores numéricos con decimales. Se utiliza como separador el punto (.). 
			Definimos campos de este tipo para precios, por ejemplo.

    blob: se usa para almacenar valores en formato binario (imágenes, archivos de sonido etc.)
	
	SQLite no provee un tipo de dato especial para almacenar fechas y horas, por lo que debemos utilizar
	alguno de los tipos existentes.
	
		Almacenamiento en un campo de tipo text

	Podemos definir un tipo de dato 'text' y respetar el formato ISO 8601, éste estándar define el 
	siguiente formato para almacenar la fecha y hora:

	YYYY-MM-DD HH:MM:SS

	Debemos respetar el orden:

    YYYY = 4 dígitos para el año.
    MM = 2 dígitos para el mes (01=enero, etc.)
    DD = 2 dígitos para el día del mes (01 a 31)
    Un espacio para separar la fecha de la hora.
    hh = 2 dígitos para la hora (00 a 23)
    mm = 2 dígitos para los minutos (00 a 59)
    ss = 2 dígitos para los segundos (00 a 59)

*/
drop table if exists facturas;
create table facturas(
	letra TEXT CHECK( letra IN ('a','b','c') ) not null DEFAULT 'a',
	numero integer,
	fecha text,
	monto real,
	primary key(letra,numero)
);

insert into facturas values 
	('a',1001,'2019-12-05',7000.00);
	
select * from facturas;

-- uso del alias
select nombre nombre_personal from clientes;

-- operador de concatenacion
select nombre||' '||apellido nombre from clientes;
-- select concat(nombre,' ',apellido) nombre from clientes;
-- no exite la funcion concatenar en sqlite

-- columnas calculadas
select *,round(monto*1.21,2) total_con_iva from facturas;
select * from x;
-- Operador distinto
select * from facturas where not letra = 'a';
select * from facturas where letra != 'a';
select * from facturas where letra <> 'a';

create table x(
	campo1 varchar(45),
	campo2 date
);
insert into x values('xx','2019-12-06');

select * from x;
select * from x where campo1!='xx';
select * from clientes;

-- left join funciona
-- right join no esta soportado

 select c.nombre,domicilio,ciudad, p.nombre
  from clientes as c
  right join provincias as p
  on codigoprovincia = p.codigo;



