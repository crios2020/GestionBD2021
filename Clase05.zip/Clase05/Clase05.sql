show databases;
use negocioWeb;
show tables;
describe clientes;

-- Consulta de catalogo de objetos de base de datos
select * from information_schema.SCHEMATA;
select SCHEMA_NAME 'Database' from information_schema.SCHEMATA;

-- Consulta de catalogo de objetos tablas
select * from information_schema.TABLES;
select TABLE_NAME Tables_in_negocioWeb from information_schema.TABLES where TABLE_SCHEMA='negocioWeb';

-- Consulta de catalogo de restricciones
select * from information_schema.TABLE_CONSTRAINTS where CONSTRAINT_SCHEMA='negocioWeb';

select * from information_schema.TABLE_CONSTRAINTS 
	where CONSTRAINT_SCHEMA='negocioWeb' 
	and TABLE_NAME ='articulos';
	
select * from information_schema.TABLE_CONSTRAINTS 
	where CONSTRAINT_SCHEMA='negocioWeb' 
	and CONSTRAINT_TYPE ='CHECK';

-- Consulta de catalogo de indices
select * from information_schema.INNODB_SYS_INDEXES isi ;

-- Consulta de catalogo de vistas
SELECT * from information_schema.VIEWS;

-- consulta de catalogo de store procedures
SELECT * from information_schema.ROUTINES;

-- consulta de catalogo de triggers
select * from information_schema.TRIGGERS;

-- consulta de catalogo de campos de una tabla
select * from information_schema.COLUMNS where TABLE_SCHEMA='negocioWeb' and TABLE_NAME ='articulos'; 

select * from information_schema.COLUMNS where TABLE_SCHEMA='negocioWeb' and TABLE_NAME ='detalles'; 

/*
 * 				Indices
 * 
 * 	Amigos
 * 
 * id		nombre			telefono
 * 1		Juan			2666666
 * 2		Eliana			2988888
 * 3		Laura			2366666
 * 4		Cristian		3855555
 * 6		Javier			2488888
 * 7		Debora			2765656
 * 
 * 
 * 			indiceAmigosNombre
 * 			nombre		id		telefono
 * 			Cristian	4		3855555
 * 			Debora		7		2765656
 * 			Eliana		2		2988888
 * 			Javier		6		2488888
 * 			Juan		1		2666666
 * 			Laura		6		2366666
 * 
 * 
 */

select * from clientes;

create index I_clientes_apellido_nombre
	on clientes(apellido,nombre);

-- falta indice unique

-- drop index

-- Consulta de catalogo de indices
select * from information_schema.INNODB_SYS_INDEXES isi ;
