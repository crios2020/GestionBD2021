-- use negocioWeb;

delimiter //
create procedure SP_test()
	begin
		select pi();
	end;
// delimiter ;

delimiter //
create procedure SP_test2()
	begin
		select curdate();	
	end;
// delimiter ;

call SP_test;
call SP_test2;

select * from V_Procedures;
show tables; 

delimiter //
create procedure SP_test3(in parametro varchar(20))
	begin
		select parametro;
    end;
// delimiter ;


drop procedure if exists SP_test4;

delimiter //
create procedure SP_test4(in parametro varchar(20), parametro2 varchar(20))
	begin
		select parametro;
    end;
// delimiter ;

call SP_test3('carlos');
-- call SP_test3();



drop procedure if exists SP_Clientes_Insert;

delimiter //
create procedure SP_Clientes_Insert(in 
		Pnombre varchar(20), 
        Papellido varchar(20),
		Pfenaci date,
		PtipoDocumento enum('DNI','LC','LE','CI','PASS'),
        PnumeroDocumento char(8),
        Ptelefono varchar(16),
        Pemail varchar(50),
        Pcalle varchar(120),
        Pnumero int,
        Ppiso varchar(12),
        Pdepto varchar(12),
        PcodigoPostal varchar(12),
        Pciudad varchar(50),
        Pprovincia varchar(50),
        Ppais varchar(50),
        Pcomentarios varchar(255)
)
	begin
		insert into direcciones (calle,numero,piso,depto,codigoPostal,ciudad,provincia,pais) 
		 	values 
            (Pcalle,Pnumero,Ppiso,Pdepto,PcodigoPostal,Pciudad,Pprovincia,Ppais);
		insert into clientes (nombre,apellido,fenaci,tipoDocumento,numeroDocumento,telefono,email,idDireccion,comentarios)
		 	values
            (Pnombre,Papellido,Pfenaci,PtipoDocumento,PnumeroDocumento,Ptelefono,Pemail,
			(select max(id) from direcciones),Pcomentarios);
    end;
// delimiter ;



/*
	nombre=Juan&apellido=Perez&fenaci=2005/05/05&tipoDocumento=DNI&numeroDocumento=1111915&telefono=222222&email=nada@nada&calle=Viel&numero=10&piso=x&depto=x&codigoPostal=1111&ciudad=CABA&provincia=CABA&pais=Argentina&comentarios=x";
       
*/

call SP_Clientes_Insert('Juanita','Viale','1990/05/05','DNI','12345678','1111111','nada@nada.com','viel',2222,'1','a','1010','CABA','CABA','Argentina','Comentarios');
select * from clientes;
select * from direcciones;


drop procedure if exists SP_Clientes_Delete;

delimiter //
create procedure SP_Clientes_Delete(in Pid int)
	begin
		delete from clientes where id=Pid;
    end;
// delimiter ;

call SP_Clientes_Delete(1);

