use negocioWeb;

create view V_Procedures as
	SELECT * from information_schema.ROUTINES;

create view V_Constraints as
	select * from information_schema.TABLE_CONSTRAINTS where CONSTRAINT_SCHEMA='negocioWeb';

create view V_Vistas as
	SELECT * from information_schema.VIEWS;

create view V_Triggers as
	select * from information_schema.TRIGGERS;

create view V_Indices as
	select i.INDEX_ID, i.NAME Nombre_Indice, t.NAME  Nombre_Tabla 
		from INFORMATION_SCHEMA.INNODB_SYS_INDEXES i join INFORMATION_SCHEMA.INNODB_SYS_TABLES t on i.TABLE_ID = t.TABLE_ID
		where t.NAME like 'negocioWeb%';

show tables;
select * from V_Procedures;
select * from V_Vistas;
select * from V_Triggers;
select * from V_Indices;
